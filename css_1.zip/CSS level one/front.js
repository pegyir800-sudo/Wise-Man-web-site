window.onload = function () {
  const splash = document.getElementById("splash");

  // Wait 10 seconds
  setTimeout(() => {

    // Start animation
    splash.classList.add("hide");
  

    // Wait for animation to finish (1 second)
    setTimeout(() => {

      // Redirect to menu page
      window.location.href = "style.html";

    }, 1000);

  }, 10000); // 10 seconds
};
